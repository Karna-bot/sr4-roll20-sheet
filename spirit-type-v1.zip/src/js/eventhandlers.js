
  on('sheet:opened', () => {
		//-getAttrs(['version'], v => { versioning(parseFloat(v.version) || 1); });
		translations();
	});

  on('clicked:shots_remove clicked:shots_add', eventinfo => updateShotsFired(eventinfo.triggerName))

	on('clicked:primary_ammo', () => updateAmmoWithShotsFired())

  on('clicked:reload', () => updateAmmoWithMax())

	sheetAttributes.tabs.forEach(attr => on(`clicked:tab_${attr}`, () => updateTab(attr)))

	on('change:agility change:walk_modifier change:run_modifier', () => updateMovement())

  sheetAttributes.calculatedAttributes.forEach(attribute => {
      const attributeArray = [`${attribute}_base`, `${attribute}_modifier`, `${attribute}_temp`, `${attribute}_temp_flag`]
      attributeArray.forEach(attr => on(`change:${attr}`, () => updateAttributes(attributeArray, attribute)))
  });

  sheetAttributes.initiative.forEach(attr => on(`change:${attr}`, () => updateAttributes(sheetAttributes.initiative, 'initiative')))

  sheetAttributes.initiative_passes.forEach(attr => on(`change:${attr}`, () => updateAttributes(sheetAttributes.initiative_passes, 'initiative_passes')))

  sheetAttributes.astral_initiative.forEach(attr => on(`change:${attr}`, () => updateAstralInitiative()))

  sheetAttributes.derivedAttributes.forEach(derivedAttribute => {
    sheetAttributes[derivedAttribute].forEach(attr => on(`change:${attr}`, () => updateDerivedAttribute(derivedAttribute)))
  })

  sheetAttributes.conditionTracks.forEach(conditionTrack => {
    sheetAttributes[conditionTrack].forEach(attr => on(`change:${attr}`, () => updateConditionTracks(conditionTrack)))
  })

	sheetAttributes.woundCalculation.forEach(attr => on(`change:${attr}`, () => updateWounds()))

  sheetAttributes.repeatingSkills.forEach(field => {
    on(`change:repeating_${field}:rating change:repeating_${field}:rating_modifier`, eventinfo => updateRepeatingSkillRating(eventinfo.triggerName))
    on(`change:repeating_${field}:attribute`, eventinfo => updateRepeatingSkillAttribute(eventinfo))
    on(`change:repeating_${field}:dicepool`, eventinfo => updateRepeatingSkillDicepool(eventinfo))
  })

  sheetAttributes.weaponTypes.forEach(type => {
    on(`change:repeating_${type}:dicepool_modifier change:repeating_${type}:specialization`, eventinfo => updateRepeatingWeaponDicepool(eventinfo.triggerName))
    on(`change:repeating_${type}:primary`, eventinfo => updateRepeatingPrimary(eventinfo, type))
  })

  sheetAttributes.rangeAttributes.forEach(attr => on(`change:repeating_range:${attr}`, eventinfo => updatePrimary(eventinfo)))

  sheetAttributes.meleeAttributes.forEach(attr => on(`change:repeating_melee:${attr}`, eventinfo => updatePrimary(eventinfo)))

  sheetAttributes.armorAttributes.forEach(attr => on(`change:repeating_armor:${attr}`, eventinfo => updatePrimary(eventinfo)))

  on("change:repeating_armor:primary", eventinfo => updateRepeatingPrimary(eventinfo, 'armor'))

  on(`change:repeating_active:skill`, eventinfo => updateRepeatingSkillName(eventinfo))

	on('clicked:cond_reset_physical clicked:cond_reset_stun', eventinfo => resetConditionTrack(eventinfo))

	on('change:edge_toggle', eventinfo => edgeToggle(eventinfo.newValue))

	on('change:device_rating change:matrix_modifier', () => updateMatrixMaximum())

	on('change:intuition change:astral_mod_modifier', () => updateAstralInitiative())

	on('change:initiative_passes_modifier change:edge_toggle change:initiative_passes_temp change:initiative_passes_temp_flag', () => updateInitiativeDice())

	on('change:astral_dice_modifier change:edge_toggle', () => updateAstralInitiativeDice())

	on('change:host_rating change:data_processing change:pilot change:intuition change:matrix_initiative_modifier change:level change:matrix_dice_modifier change:edge_toggle', () => updateMatrixInitiative())

  on("clicked:cond_reset", () => resetNpcCondition()); 

  sheetAttributes.spellTypes.forEach(type => on(`change:repeating_${type}:dicepool_modifier change:repeating_${type}:specialization`, eventinfo => updateSpellsDicepool(eventinfo)))

  on("change:level", eventinfo => updateSpriteConditionTrack(eventinfo.newValue))

  on("change:host_rating", eventinfo => updateHostAttributes(eventinfo.newValue))

  on("change:default_attribute", eventinfo => updateDefaultAttribute(eventinfo.newValue))

  on('change:force change:sheet_type change:edge_offset ' + SPIRIT_ATTRIBUTES.map(attr => `change:${attr}_offset`).join(' '), () => updateSpiritAttributes())

  on('change:sheet_type', eventinfo => { if (eventinfo.newValue === 'spirit') setAttrs({flag_special: 'magic'}) })

  on(`change:${sheetAttributes.defense.join(' change:')} change:spirit_state change:sheet_type`, () => updateDefense())
